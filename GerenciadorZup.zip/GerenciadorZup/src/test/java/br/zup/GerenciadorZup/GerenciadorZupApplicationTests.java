package br.zup.GerenciadorZup;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GerenciadorZupApplicationTests {

	@Test
	void contextLoads() {
	}

}
