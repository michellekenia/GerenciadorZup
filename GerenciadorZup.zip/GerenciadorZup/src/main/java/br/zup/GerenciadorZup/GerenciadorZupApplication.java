package br.zup.GerenciadorZup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GerenciadorZupApplication {

	public static void main(String[] args) {
		SpringApplication.run(GerenciadorZupApplication.class, args);
	}

}
